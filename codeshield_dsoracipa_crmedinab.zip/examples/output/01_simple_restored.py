def calcular_promedio(numeros):
    total = sum(numeros)
    cantidad = len(numeros)
    return total / cantidad



valores = [10, 20, 30, 40]
resultado = calcular_promedio(valores)
print(f"El promedio es: {resultado}")
