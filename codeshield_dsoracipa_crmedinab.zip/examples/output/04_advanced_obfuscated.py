
from functools import wraps


def _f0000(_p0001):
    @wraps(_p0001)
    def _f0002(*_p0004, **_p0003):
        _f0002.contador += 1
        return _p0001(*_p0004, **_p0003)
    _f0002.contador = 0
    return _f0002


@_f0000
def _f0005(_p0006):
    return _p0006 ** 2


def _f0007(_p0008):
    _v0009 = [_v000a for _v000a in _p0008 if _v000a % 2 == 0]
    _v000b = list(map(lambda _p0006: _f0005(_p0006), _v0009))
    return {_v000a: _v000c for _v000a, _v000c in zip(_v0009, _v000b)}


if __name__ == __import__("base64").b64decode("X19tYWluX18=").decode("utf-8"):
    _v000d = list(range(1, 11))
    _v000e = _f0007(_v000d)
    print(__import__("base64").b64decode("UmVzdWx0YWRvczo=").decode("utf-8"))
    for _v000f, _v0010 in sorted(_v000e.items()):
        print(f"  {_v000f} -> {_v0010}")
    print(f"cuadrado() fue llamado {_f0005.contador} veces")
