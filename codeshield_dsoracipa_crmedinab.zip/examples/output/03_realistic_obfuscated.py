
import json


def _f0000(_p0001):
    return {_v0002[__import__("base64").b64decode("aWQ=").decode("utf-8")]: _v0002 for _v0002 in _p0001}


def _f0003(_p0005, _p0004):
    return [_v0002 for _v0002 in _p0005.values() if _v0002[__import__("base64").b64decode("c3RvY2s=").decode("utf-8")] < _p0004]


def _f0006(_p0005):
    return sum(_v0002[__import__("base64").b64decode("cHJlY2lv").decode("utf-8")] * _v0002[__import__("base64").b64decode("c3RvY2s=").decode("utf-8")] for _v0002 in _p0005.values())


def _f0007(_p0005, _p0008):
    _v0009 = _f0006(_p0005)
    _v000a = _f0003(_p0005, _p0008)
    print(__import__("base64").b64decode("PT09IFJFUE9SVEUgREUgSU5WRU5UQVJJTyA9PT0=").decode("utf-8"))
    print(f"Valor total: ${_v0009:,.2f}")
    print(f"Productos con stock bajo (<{_p0008}):")
    for _v000b in _v000a:
        print(f"  - {_v000b['nombre']} (stock: {_v000b['stock']})")


if __name__ == __import__("base64").b64decode("X19tYWluX18=").decode("utf-8"):
    _p0001 = [
        {__import__("base64").b64decode("aWQ=").decode("utf-8"): 1, __import__("base64").b64decode("bm9tYnJl").decode("utf-8"): __import__("base64").b64decode("TGFwdG9w").decode("utf-8"), __import__("base64").b64decode("cHJlY2lv").decode("utf-8"): 2500.0, __import__("base64").b64decode("c3RvY2s=").decode("utf-8"): 3},
        {__import__("base64").b64decode("aWQ=").decode("utf-8"): 2, __import__("base64").b64decode("bm9tYnJl").decode("utf-8"): __import__("base64").b64decode("TW91c2U=").decode("utf-8"), __import__("base64").b64decode("cHJlY2lv").decode("utf-8"): 25.0, __import__("base64").b64decode("c3RvY2s=").decode("utf-8"): 50},
        {__import__("base64").b64decode("aWQ=").decode("utf-8"): 3, __import__("base64").b64decode("bm9tYnJl").decode("utf-8"): __import__("base64").b64decode("VGVjbGFkbw==").decode("utf-8"), __import__("base64").b64decode("cHJlY2lv").decode("utf-8"): 80.0, __import__("base64").b64decode("c3RvY2s=").decode("utf-8"): 2},
        {__import__("base64").b64decode("aWQ=").decode("utf-8"): 4, __import__("base64").b64decode("bm9tYnJl").decode("utf-8"): __import__("base64").b64decode("TW9uaXRvcg==").decode("utf-8"), __import__("base64").b64decode("cHJlY2lv").decode("utf-8"): 350.0, __import__("base64").b64decode("c3RvY2s=").decode("utf-8"): 8},
    ]
    _v000c = _f0000(_p0001)
    _f0007(_v000c, _p0008=5)
