class _C0000:

    def __init__(self, _p0002, _p0001):
        self.nombre = _p0002
        self.edad = _p0001

    def saludar(self):
        return f"Hola, soy {self.nombre} y tengo {self.edad} anos"


class _C0003(_C0000):
    def __init__(self, _p0002, _p0001, _p0004):
        super().__init__(_p0002, _p0001)
        self.carrera = _p0004

    def presentarse(self):
        _v0005 = self.saludar()
        return f"{_v0005}. Estudio {self.carrera}"


def _f0006():
    _v0007 = [
        _C0003(__import__("base64").b64decode("QW5h").decode("utf-8"), 20, __import__("base64").b64decode("U2lzdGVtYXM=").decode("utf-8")),
        _C0003(__import__("base64").b64decode("THVpcw==").decode("utf-8"), 22, __import__("base64").b64decode("TWVjYW5pY2E=").decode("utf-8")),
    ]
    for _v0008 in _v0007:
        print(_v0008.presentarse())


if __name__ == __import__("base64").b64decode("X19tYWluX18=").decode("utf-8"):
    _f0006()
